﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Modulo_ordenes
{
    internal class Ordenes
    {
        private string cadenaConexion = "Data Source=DESKTOP-RSJBFKD\\SQLEXPRESS;Initial Catalog=Codelex;Integrated Security=True;Encrypt=False";






    }
}
