﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modulo_ordenes
{
    internal class LocacionTipoModel
    {
        public int IdLocacion { get; set; }
        public string TipoLocacion { get; set; } // Propiedad en C#
    }
}
