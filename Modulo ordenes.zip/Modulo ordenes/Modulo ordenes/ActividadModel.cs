﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modulo_ordenes
{
    internal class ActividadModel
    {

        public int IdActividad { get; set; }
        public int IdServicio { get; set; }
        public string Descripcion { get; set; }
        public string Frecuencia { get; set; }
        public decimal Precio { get; set; }
    }
}
