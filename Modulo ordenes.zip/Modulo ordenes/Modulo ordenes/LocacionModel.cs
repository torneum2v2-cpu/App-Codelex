﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modulo_ordenes
{
    internal class LocacionModel
    {
        public int IdLocacion { get; set; }
        public string NombreLocacion { get; set; }
        public string TipoLocacion { get; set; }
    }
}
