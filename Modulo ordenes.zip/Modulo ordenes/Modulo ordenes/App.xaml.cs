﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Modulo_ordenes
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
