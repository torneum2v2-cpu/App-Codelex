﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modulo_ordenes
{
    internal class EmpleadoModel
    {
        public int IdEmpleado { get; set; }
        public string NombreCompleto { get; set; }
        public string Identidad { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
    }
}

