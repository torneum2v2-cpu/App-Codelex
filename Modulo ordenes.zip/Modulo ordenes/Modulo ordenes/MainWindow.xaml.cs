﻿using Codelex.BDD;
using Microsoft.Data.SqlClient;
using System.Collections.ObjectModel;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Modulo_ordenes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window


    {
        public MainWindow()
        {
            InitializeComponent();

            llenar_cmbProducto();

            CargarClientes();

            CargarEmpleadosDisponibles();

            CargarLocaciones();

            CargartipoLocaciones();

            CargarServicios();

            CargarVehiculos();

            CargarActividades();

            CargarTurnos();

            CargarSupervisores();
        }

        private ObservableCollection<EmpleadoModel> listaDisponibles = new ObservableCollection<EmpleadoModel>();
        private ObservableCollection<EmpleadoModel> listaAsignados = new ObservableCollection<EmpleadoModel>();

        private ObservableCollection<ActividadModel> listaActividadesDisponibles = new ObservableCollection<ActividadModel>();
        private ObservableCollection<ActividadModel> listaActividadesAsignadas = new ObservableCollection<ActividadModel>();

        private void CargarEmpleadosDisponibles()
        {
           listaDisponibles.Clear();
            string consulta = "SELECT empleado_id, nombreEmpleado, apellidoEmpleado, identidad, telefonoEmpleado, correoEmpleado FROM EMPLEADOS";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaDisponibles.Add(new EmpleadoModel
                                {
                                    IdEmpleado = Convert.ToInt32(lector["empleado_id"]),
                                    NombreCompleto = lector["nombreEmpleado"].ToString() + " " + lector["apellidoEmpleado"].ToString(),
                                    Identidad = lector["identidad"] != DBNull.Value ? lector["identidad"].ToString() : "",
                                    Telefono = lector["telefonoEmpleado"] != DBNull.Value ? lector["telefonoEmpleado"].ToString() : "",
                                    Correo = lector["correoEmpleado"] != DBNull.Value ? lector["correoEmpleado"].ToString() : ""
                                });
                            }
                        }
                    }

                    // Configuramos el ListBox de disponibles
                    lstEmpleadosDisponibles.ItemsSource = listaDisponibles;
                    lstEmpleadosDisponibles.DisplayMemberPath = "NombreCompleto";

                    // Configuramos el ListBox de asignados (si se llama lstEmpleadosAsignados en tu XAML)
                    lstEmpleadosAsignados.ItemsSource = listaAsignados;
                    lstEmpleadosAsignados.DisplayMemberPath = "NombreCompleto";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar los empleados: " + ex.Message);
                }
            }
        }

        private void CargarSupervisores()
        {
            var listaSupervisores = new List<EmpleadoModel>();

            // Filtramos directamente por el cargo_id que corresponda al supervisor (en este caso 3)
            string consulta = "SELECT empleado_id, nombreEmpleado, apellidoEmpleado FROM EMPLEADOS WHERE cargo_id = 3";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaSupervisores.Add(new EmpleadoModel
                                {
                                    IdEmpleado = Convert.ToInt32(lector["empleado_id"]),
                                    NombreCompleto = lector["nombreEmpleado"].ToString() + " " + lector["apellidoEmpleado"].ToString()
                                });
                            }
                        }
                    }

                    // Enlazamos los datos al ComboBox del supervisor en la interfaz
                    cmbSupervisor.ItemsSource = listaSupervisores;
                    cmbSupervisor.DisplayMemberPath = "NombreCompleto";
                    cmbSupervisor.SelectedValuePath = "IdEmpleado";

                    if (cmbSupervisor.Items.Count > 0)
                    {
                        cmbSupervisor.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar los supervisores: " + ex.Message);
                }
            }
        }

        private void CargarVehiculos()
        {
            var listaVehiculos = new List<VehiculoModel>();

            string consulta = "SELECT vehiculo_id, placa, marcaVehiculo, modeloVehiculo FROM VEHICULOS";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaVehiculos.Add(new VehiculoModel
                                {
                                    IdVehiculo = Convert.ToInt32(lector["vehiculo_id"]),
                                    Placa = lector["placa"].ToString(),
                                    // Combinamos marca y modelo para que se vea genial en el ComboBox (ej: "Toyota - Hilux")
                                    MarcaVehiculo = lector["marcaVehiculo"].ToString() + " - " + lector["modeloVehiculo"].ToString()
                                });
                            }
                        }
                    }

                    // Si lo vas a mostrar en un ComboBox (ej: cmbVehiculos):
                    cmbVehiculo.ItemsSource = listaVehiculos;
                    cmbVehiculo.DisplayMemberPath = "MarcaVehiculo"; // Lo que verá el usuario
                    cmbVehiculo.SelectedValuePath = "IdVehiculo";     // El ID interno para guardar la orden

                    if (cmbVehiculo.Items.Count > 0)
                    {
                        cmbVehiculo.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar los vehículos: " + ex.Message);
                }
            }
        }

        private void llenar_cmbProducto()
        {
            string consulta = "SELECT nombreProducto FROM PRODUCTOS";

            // Usamos 'using' para asegurar que la conexión y el comando se cierren y se liberen correctamente
            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    // 2. Pasamos la consulta y la conexión directamente al crear el SqlCommand
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                // 3. Leemos el valor (usar el índice 0 es más seguro si solo traes una columna)
                                cmbProducto_equipo.Items.Add(lector.GetString(0));
                            }
                        }
                    }

                    // Seleccionamos el primer elemento solo si hay elementos para evitar excepciones
                    if (cmbProducto_equipo.Items.Count > 0)
                    {
                        cmbProducto_equipo.SelectedIndex = 0;
                    }
                }
                catch(Exception ex)
                {
                    // Opcional: Muestra el error si algo falla para que puedas depurar
                    MessageBox.Show("Error al cargar productos: " + ex.Message);
                }
            }


        }

        private void CargarActividades()
        {
            listaActividadesDisponibles.Clear();
            string consulta = "SELECT actividad_id, servicio_id, descripcion, frecuencia, precio FROM ACTIVIDADES";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaActividadesDisponibles.Add(new ActividadModel
                                {
                                    IdActividad = Convert.ToInt32(lector["actividad_id"]),
                                    IdServicio = Convert.ToInt32(lector["servicio_id"]),
                                    Descripcion = lector["descripcion"].ToString(),
                                    Frecuencia = lector["frecuencia"] != DBNull.Value ? lector["frecuencia"].ToString() : "",
                                    Precio = lector["precio"] != DBNull.Value ? Convert.ToDecimal(lector["precio"]) : 0.00m
                                });
                            }
                        }
                    }

                    // Configuramos el ListBox de disponibles
                    lstActividadesDisponibles.ItemsSource = listaActividadesDisponibles;
                    lstActividadesDisponibles.DisplayMemberPath = "Descripcion";

                    // Configuramos el ListBox de la orden (asignadas)
                    lstActividadesOrden.ItemsSource = listaActividadesAsignadas;
                    lstActividadesOrden.DisplayMemberPath = "Descripcion";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar las actividades: " + ex.Message);
                }
            }
        }
        private void CargartipoLocaciones()
        {
            var listaLocaciones = new List<LocacionModel>();

            string consulta = "SELECT locacion_id, tipoLocacion FROM LOCACIONES";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaLocaciones.Add(new LocacionModel
                                {
                                    IdLocacion = Convert.ToInt32(lector["locacion_id"]),
                                    TipoLocacion = lector["tipoLocacion"].ToString()
                                });
                            }
                        }
                    }

                    // Enlazamos los datos al ComboBox de la interfaz
                    cmbTipoLocacion.ItemsSource = listaLocaciones;
                    cmbTipoLocacion.DisplayMemberPath = "TipoLocacion"; // Lo que el usuario ve
                    cmbTipoLocacion.SelectedValuePath = "IdLocacion";    // El ID interno que se usará al guardar la orden

                    // Opcional: Seleccionar el primer elemento por defecto para que no aparezca vacío
                    if (cmbTipoLocacion.Items.Count > 0)
                    {
                        cmbTipoLocacion.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar las locaciones: " + ex.Message);
                }
            }
        }

        private void CargarLocaciones()
        {
            var listaLocaciones = new List<LocacionModel>();

            string consulta = "SELECT locacion_id, nombreLocacion FROM LOCACIONES";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaLocaciones.Add(new LocacionModel
                                {
                                    IdLocacion = Convert.ToInt32(lector["locacion_id"]),
                                    NombreLocacion = lector["nombreLocacion"].ToString()
                                });
                            }
                        }
                    }

                    // Enlazamos los datos al ComboBox de la interfaz
                    cmbLocacion.ItemsSource = listaLocaciones;
                    cmbLocacion.DisplayMemberPath = "NombreLocacion"; // Lo que el usuario ve
                    cmbLocacion.SelectedValuePath = "IdLocacion";    // El ID interno que se usará al guardar la orden

                    // Opcional: Seleccionar el primer elemento por defecto para que no aparezca vacío
                    if (cmbLocacion.Items.Count > 0)
                    {
                        cmbLocacion.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar las locaciones: " + ex.Message);
                }
            }
        }

        private void CargarServicios()
        {
            var listaServicios = new List<ServicioModel>();

            string consulta = "SELECT servicio_id, nombreServicio FROM SERVICIOS";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaServicios.Add(new ServicioModel
                                {
                                    IdServicio = Convert.ToInt32(lector["servicio_id"]),
                                    NombreServicio = lector["nombreServicio"].ToString()
                                });
                            }
                        }
                    }

                    // Enlazamos los datos al ComboBox (asegúrate de que el nombre coincida con tu XAML, ej: cmbServicios)
                    cmbTipo_Servicio.ItemsSource = listaServicios;
                    cmbTipo_Servicio.DisplayMemberPath = "NombreServicio"; // Coincide con la propiedad de C#
                    cmbTipo_Servicio.SelectedValuePath = "IdServicio";    // El ID que se usará al guardar

                    if (cmbTipo_Servicio.Items.Count > 0)
                    {
                        cmbTipo_Servicio.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar los servicios: " + ex.Message);
                }
            }
        }



        private void btnLimpiarClientes(object sender, RoutedEventArgs e)
        {
            TxtIdentidad.Clear();
            TxtEmpresa.Clear();
            TxtContacto.Clear();
            TxtApellido.Clear();
            TxtTelefono.Clear();
            TxtCorreo.Clear();

            
        }

        private void btnAgregar_Click(object sender, RoutedEventArgs e)
        {
            if (lstActividadesDisponibles.SelectedItems.Count > 0)
            {
                var seleccionadas = lstActividadesDisponibles.SelectedItems.Cast<ActividadModel>().ToList();

                foreach (var actividad in seleccionadas)
                {
                    listaActividadesDisponibles.Remove(actividad); // La quita de disponibles
                    listaActividadesAsignadas.Add(actividad);      // La pasa a la orden
                }
            }
        }

        private void btnAgregarProducto_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnQuitarProducto_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnNuevaOrden_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnGuardarOrden_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnQuitar_Click(object sender, RoutedEventArgs e)
        {
            if (lstActividadesOrden.SelectedItems.Count > 0)
            {
                var seleccionadas = lstActividadesOrden.SelectedItems.Cast<ActividadModel>().ToList();

                foreach (var actividad in seleccionadas)
                {
                    listaActividadesAsignadas.Remove(actividad);   // La quita de la orden
                    listaActividadesDisponibles.Add(actividad);    // La regresa a disponibles
                }
            }
        }

        private void dgClientes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgClientes.SelectedItem is ClienteModel clienteSeleccionado)
            {
                TxtIdentidad.Text = clienteSeleccionado.Identificacion;
                TxtEmpresa.Text = clienteSeleccionado.Empresa;
                TxtContacto.Text = clienteSeleccionado.Nombre;
                TxtApellido.Text = clienteSeleccionado.Apellido;
                TxtTelefono.Text = clienteSeleccionado.Telefono;
                TxtCorreo.Text = clienteSeleccionado.Correo;
            }
        }

        private void txtBuscar_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtBuscarCliente != null)
            {
                CargarClientes(txtBuscarCliente.Text);
            }
        }

        private void CargarClientes(string filtro = "")
        {
            var listaClientes = new List<ClienteModel>();

            // Usamos exactamente los nombres de tus columnas en SQL
            string consulta = "SELECT TOP 50 cliente_id, nombreEmpresa, nombreCliente, apellidoCliente, telefonoCliente, identificacionCliente, correoCliente " +
                              "FROM CLIENTES WHERE nombreEmpresa LIKE @filtro OR identificacionCliente LIKE @filtro OR nombreCliente LIKE @filtro";

            using (SqlConnection conexionBD = Conexion.ObtenerConexion())
            {
                try
                {
                    using (SqlCommand comando = new SqlCommand(consulta, conexionBD))
                    {
                        comando.Parameters.AddWithValue("@filtro", "%" + filtro + "%");

                        using (SqlDataReader lector = comando.ExecuteReader())
                        {
                            while (lector.Read())
                            {
                                listaClientes.Add(new ClienteModel
                                {
                                    IdCliente = lector["cliente_id"].ToString(),
                                    Empresa = lector["nombreEmpresa"].ToString(),
                                    Nombre = lector["nombreCliente"].ToString(),
                                    Apellido = lector["apellidoCliente"].ToString(),
                                    Telefono = lector["telefonoCliente"].ToString(),
                                    Identificacion = lector["identificacionCliente"].ToString(),
                                    Correo = lector["correoCliente"].ToString()
                                });
                            }
                        }
                    }

                    dgClientes.ItemsSource = listaClientes;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar los clientes: " + ex.Message);
                }
            }
        }

        private void CargarTurnos()
        {
            // Lista de turnos disponibles para las órdenes de limpieza
            var listaTurnos = new List<string>
            {
                 "Matutino",
                "Vespertino",
                "Nocturno",
                "Mixto / Especial"
             };

            // Enlazamos los datos al ComboBox de turnos
            cmbTurno.ItemsSource = listaTurnos;

            // Seleccionar el primer elemento por defecto para que no aparezca vacío
            if (cmbTurno.Items.Count > 0)
            {
                cmbTurno.SelectedIndex = 0;
            }
        }




        private void btnAgregarEmpleado_Click(object sender, RoutedEventArgs e)
        {
            if (lstEmpleadosDisponibles.SelectedItems.Count > 0)
            {
                // Creamos una lista temporal para evitar errores al modificar la colección mientras se recorre
                var seleccionados = lstEmpleadosDisponibles.SelectedItems.Cast<EmpleadoModel>().ToList();

                foreach (var empleado in seleccionados)
                {
                    listaDisponibles.Remove(empleado); // Lo quita de disponibles
                    listaAsignados.Add(empleado);      // Lo agrega a asignados
                }
            }
        }

        private void btnQuitarEmpleado_Click(object sender, RoutedEventArgs e)
        {
            if (lstEmpleadosAsignados.SelectedItems.Count > 0)
            {
                var seleccionados = lstEmpleadosAsignados.SelectedItems.Cast<EmpleadoModel>().ToList();

                foreach (var empleado in seleccionados)
                {
                    listaAsignados.Remove(empleado);   // Lo quita de asignados
                    listaDisponibles.Add(empleado);    // Lo regresa a disponibles
                }
            }
        }
    }
}