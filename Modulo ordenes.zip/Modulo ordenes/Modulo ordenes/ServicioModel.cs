﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modulo_ordenes
{
    internal class ServicioModel
    {
        public int IdServicio { get; set; }
        public string NombreServicio { get; set; }
    }
}
