﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Modulo_ordenes
{
    internal class VehiculoModel
    {
        public int IdVehiculo { get; set; }
        public string Placa { get; set; }
        public string MarcaVehiculo { get; set; }
        public string ModeloVehiculo { get; set; }
    }
}
