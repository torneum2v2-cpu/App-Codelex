﻿using System;

namespace Modulo_ordenes // Asegúrate de que coincida con el namespace de tu MainWindow
{
    public class ClienteModel
    {
        public string IdCliente { get; set; }
        public string Empresa { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Telefono { get; set; }
        public string Identificacion { get; set; }
        public string Correo { get; set; }
    }
}